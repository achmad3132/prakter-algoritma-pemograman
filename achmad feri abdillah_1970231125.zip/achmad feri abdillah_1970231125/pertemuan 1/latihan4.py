#tipe data boolean
print(True)

#tipe data string
print("ayo belajar python")
print('belajar python sangat mudah')

#tipe data integer
print(20)

#tipe data float
print(3.14)


#tipe data complex
print(5j)
#tipe data list
print({1,2,3,4,5})
print({"satu","dua","tiga"})
#tipe data tuple
print((1,2,3,4,5))
print(("satu","dua","tiga"))

print({"nama":"Budi",'umur':20})
biodata = {"nama":"Andi",'umur':20}
print(biodata)
print(type(biodata))