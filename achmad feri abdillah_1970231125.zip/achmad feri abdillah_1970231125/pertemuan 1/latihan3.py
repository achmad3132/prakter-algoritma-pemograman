#variable adalah tempat menyimpan data

#menaru /assignment nilai

a = 10
x = 5 

panjang = 1000

#pemanggilan pertama
print("nilai a =",a)
print("nilai x =",x)
print("nilai panjang=",panjang)

#penamaan 
nilai_y = 15#dengan menggunakan undercore
juta10 = 10000000#ini boleh
nilaiZ = 17.5

#pemanggilan kedua
print("nilai a =",a)
a = 7
print("nilai a =",a)

#assignment indirect

b = a 
print("nilai b =",b)