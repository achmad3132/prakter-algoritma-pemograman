import time
start_time = time.time()
print("hello")
print("world")
print("hello world")

print("halo chantiiek")

#ini adalah comment
a = 10

print(a)
print(time.time()- start_time,"detik")