print("hello dunia!!!")
print("apa kabar kalian?")
print("instalasi berhasil")