# while loop
# while kondisi:
# aksi ini
# aksi itu

# akhir dari program

angka = 0
print(f"angka sekarang -> {angka}")

while angka < 5: angka += 1
print(f"angka sekarang -> {angka}")
print("otong ganteng maxsyimaal!")

print("cukuuup")